pigs w 22 0 
pigs w 23 1 
pigs w 24 0 
echo "Now in idle mode"