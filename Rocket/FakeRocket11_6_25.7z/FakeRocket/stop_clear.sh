pigs wvtx 0 
pigs wvclr 
echo "Wave stopped and cleared"