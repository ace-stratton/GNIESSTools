import spidev
import RPi.GPIO as GPIO
import time
import pigpio

pi = pigpio.pi()

# --- Pin Configuration ---
SPI_BUS, SPI_DEV = 0, 0
LOAD_PIN = 22  # choose a GPIO you wired to LOAD+ (through LVDS/RS422 driver)
pi.set_mode(LOAD_PIN, pigpio.OUTPUT)
CLK_PIN = 17
pi.set_mode(CLK_PIN, pigpio.OUTPUT)

# --- GPIO Setup ---




# --- SPI Setup ---
spi = spidev.SpiDev()
spi.open(SPI_BUS, SPI_DEV)
spi.max_speed_hz = 2400000     # 2.5 MHz clock
spi.mode = 0                  
spi.bits_per_word = 8
spi.no_cs = True                 # manual LOAD control

# --- Parameters ---
CLOCK_PERIOD = 0.000000417
T_PULSE_US = CLOCK_PERIOD/2     # LOAD low time
T_SETUP_US = CLOCK_PERIOD/2     # delay after LOAD high before first clock

pi.wave_clear()

wf = [
    pigpio.pulse(0, 1 << LOAD_PIN, 0),  # drive LOW for 2 µs
    pigpio.pulse(1 << LOAD_PIN, 0, 0),  # back HIGH (0 µs hold)
    
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    pigpio.pulse(1 << CLK_PIN, 0, 0),  # clk HIGH (0 µs hold)
    pigpio.pulse(0, 1 << CLK_PIN, 0), 
    ]

pi.wave_add_serial(wf)
wave_id = pi.wave_create()




def receive_16bits():
    """Generate a load pulse, then read 16 bits (2 bytes) from SPI slave."""
    # LOAD active low pulse
    

    
    #while pi.wave_tx_busy():
        #pass

    
    pi.wave_send_once(wave_id)

    # Clock in 16 bits (2 bytes)
    rx_bytes = spi.writebytes([0, 0]) # Will send out zeros, while same time receiving 2 bytes, 16 bit. Stoopid design 
    
    # Combine two bytes into one 16-bit word
    #value = (rx_bytes[0] << 8) | rx_bytes[1]
    return #value

try:
    while True:
        data = receive_16bits()
        #print(f"Received: 0x{data:04X}")
        print('running')
        time.sleep(0.00006)  # 60us between samples
finally:
    spi.close()
    pi.wave_delete(wave_id)
    pi.stop()
   
